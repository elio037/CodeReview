package pen;

public class Pen {
    private int productId;
    private String name;
    private String brand;
    private String category;
    private int price;
    private boolean inStock;

    public Pen(int productId, String name, String brand, String category, int price, boolean inStock) {
        this.productId = productId;
        this.name = name;
        this.brand = brand;
        this.category = category;
        this.price = price;
        this.inStock = inStock;
    }

    public String toString() {
        return "[" + productId + ", " + name + ", " + brand + ", " + category + ", " + price + "원, "
                + (inStock ? "재고 있음" : "품절") + "]";
    }

    public boolean isInStock() {
        return inStock;
    }
}